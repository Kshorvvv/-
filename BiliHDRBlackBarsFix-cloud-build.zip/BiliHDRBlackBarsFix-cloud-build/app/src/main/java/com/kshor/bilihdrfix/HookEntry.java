package com.kshor.bilihdrfix;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V3 Flags-only build.
 *
 * Important:
 * - Does NOT call Window#setBackgroundDrawable.
 * - Does NOT call DecorView#setBackgroundColor.
 * - Does NOT hook SurfaceView / TextureView / player render view.
 *
 * It only clears wallpaper/translucent/no-limits flags and sets system bars black.
 * This is a safe diagnostic version: it should not make video black.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliHDRBlackBarsFixV3";

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bilibilihd",
            "tv.danmaku.bili",
            "com.bilibili.app.in"
    ));

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded in " + lpparam.packageName);
        hookActivityLifecycle();
    }

    private static void hookActivityLifecycle() {
        XposedBridge.hookAllMethods(Activity.class, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                patchWindowFlags((Activity) param.thisObject);
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                final Activity activity = (Activity) param.thisObject;
                patchWindowFlags(activity);
                View decor = safeDecor(activity);
                if (decor != null) {
                    decor.postDelayed(() -> patchWindowFlags(activity), 300);
                    decor.postDelayed(() -> patchWindowFlags(activity), 1000);
                    decor.postDelayed(() -> patchWindowFlags(activity), 2500);
                }
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onWindowFocusChanged", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                patchWindowFlags((Activity) param.thisObject);
            }
        });
    }

    private static View safeDecor(Activity activity) {
        try {
            Window w = activity != null ? activity.getWindow() : null;
            return w != null ? w.getDecorView() : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static void patchWindowFlags(Activity activity) {
        if (activity == null) return;
        try {
            Window w = activity.getWindow();
            if (w == null) return;

            int flagsToClear =
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                            | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER;

            w.clearFlags(flagsToClear);
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

            if (Build.VERSION.SDK_INT >= 21) {
                w.setStatusBarColor(Color.BLACK);
                w.setNavigationBarColor(Color.BLACK);
            }

            if (Build.VERSION.SDK_INT >= 29) {
                w.setStatusBarContrastEnforced(false);
                w.setNavigationBarContrastEnforced(false);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchWindowFlags failed: " + t);
        }
    }
}
