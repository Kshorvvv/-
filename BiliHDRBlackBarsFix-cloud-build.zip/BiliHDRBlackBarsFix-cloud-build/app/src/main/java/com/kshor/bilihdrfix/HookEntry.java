package com.kshor.bilihdrfix;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V2 Drop-in Conservative build.
 *
 * Fix target:
 * - Android 15 + Bilibili HD HDR playback may show wallpaper in letterbox / safe-area background.
 *
 * Safety scope:
 * - Only patches Activity window/decor background and system bars to black.
 * - DOES NOT hook SurfaceView / TextureView / player render view.
 * - DOES NOT touch network APIs, membership checks, region checks, DRM, cookies, tokens, ads, or playback authorization.
 *
 * Why V2:
 * - V1 also patched SurfaceView / TextureView opacity. On some devices/video renderers this can make
 *   the actual video surface black. V2 removes all video-surface hooks.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliHDRBlackBarsFixV2";

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bilibilihd",
            "tv.danmaku.bili",
            "com.bilibili.app.in"
    ));

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": loaded in " + lpparam.packageName);

        hookActivityLifecycle();
    }

    private static void hookActivityLifecycle() {
        XposedBridge.hookAllMethods(Activity.class, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity activity = (Activity) param.thisObject;
                applyBlackWindowBackground(activity);
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity activity = (Activity) param.thisObject;
                applyBlackWindowBackground(activity);

                View decor = safeDecor(activity);
                if (decor != null) {
                    decor.postDelayed(() -> applyBlackWindowBackground(activity), 300);
                    decor.postDelayed(() -> applyBlackWindowBackground(activity), 1000);
                    decor.postDelayed(() -> applyBlackWindowBackground(activity), 2500);
                }
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onWindowFocusChanged", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity activity = (Activity) param.thisObject;
                applyBlackWindowBackground(activity);
            }
        });
    }

    private static View safeDecor(Activity activity) {
        try {
            Window w = activity != null ? activity.getWindow() : null;
            return w != null ? w.getDecorView() : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static void applyBlackWindowBackground(Activity activity) {
        if (activity == null) return;

        try {
            Window w = activity.getWindow();
            if (w == null) return;

            // Patch only the container background, not the video rendering surfaces.
            w.setBackgroundDrawable(new ColorDrawable(Color.BLACK));

            // Remove flags that can leave wallpaper or transparent system regions visible.
            int flagsToClear =
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                            | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER;
            w.clearFlags(flagsToClear);

            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

            if (Build.VERSION.SDK_INT >= 21) {
                w.setStatusBarColor(Color.BLACK);
                w.setNavigationBarColor(Color.BLACK);
            }

            View decor = w.getDecorView();
            if (decor != null) {
                // This should sit behind the app content rather than covering the video surface.
                decor.setBackgroundColor(Color.BLACK);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": window patch failed: " + t);
        }
    }
}
