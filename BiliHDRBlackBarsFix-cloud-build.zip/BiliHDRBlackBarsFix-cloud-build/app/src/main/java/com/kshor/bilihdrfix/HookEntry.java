package com.kshor.bilihdrfix;

import android.app.Activity;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V5 DeepLog diagnostic build.
 *
 * Changes NOTHING.
 * Logs:
 * - Activity lifecycle/window flags
 * - deep view tree snapshots
 * - ViewGroup.addView child/parent classes
 * - SurfaceView/TextureView creation
 *
 * Goal:
 * Find the real Bilibili HD player container without touching Window, DecorView, SurfaceView, or TextureView.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliHDRDeep";
    private static final int MAX_LOG_LINES_PER_DUMP = 260;
    private static final int MAX_DEPTH = 16;

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bilibilihd",
            "tv.danmaku.bili",
            "com.bilibili.app.in"
    ));

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": loaded process=" + lpparam.processName + " package=" + lpparam.packageName);

        hookActivityLifecycle();
        hookSetContentView();
        hookAddView();
        hookSurfaceTextureConstructors();
    }

    private static void hookActivityLifecycle() {
        XposedBridge.hookAllMethods(Activity.class, "onCreate", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                logActivity("onCreate", a, true);
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                final Activity a = (Activity) param.thisObject;
                logActivity("onResume", a, true);
                View decor = safeDecor(a);
                if (decor != null) {
                    decor.postDelayed(() -> logActivity("snapshot+1000ms", a, true), 1000);
                    decor.postDelayed(() -> logActivity("snapshot+3000ms", a, true), 3000);
                    decor.postDelayed(() -> logActivity("snapshot+7000ms", a, true), 7000);
                    decor.postDelayed(() -> logActivity("snapshot+12000ms", a, true), 12000);
                }
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onWindowFocusChanged", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                logActivity("focusChanged=" + param.args[0], a, true);
            }
        });
    }

    private static void hookSetContentView() {
        XposedBridge.hookAllMethods(Activity.class, "setContentView", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                logActivity("after setContentView args=" + param.args.length, a, true);
            }
        });
    }

    private static void hookAddView() {
        XposedBridge.hookAllMethods(ViewGroup.class, "addView", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    View child = null;
                    for (Object arg : param.args) {
                        if (arg instanceof View) {
                            child = (View) arg;
                            break;
                        }
                    }
                    if (child == null) return;

                    String p = parent.getClass().getName();
                    String c = child.getClass().getName();
                    if (isInterestingClass(p) || isInterestingClass(c) || child instanceof SurfaceView || child instanceof TextureView) {
                        XposedBridge.log(TAG + ": addView parent=" + brief(parent) + " child=" + brief(child));
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": addView log failed: " + t);
                }
            }
        });
    }

    private static void hookSurfaceTextureConstructors() {
        XposedBridge.hookAllConstructors(SurfaceView.class, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                try {
                    SurfaceView v = (SurfaceView) param.thisObject;
                    XposedBridge.log(TAG + ": SurfaceView constructed " + brief(v));
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": SurfaceView constructor log failed: " + t);
                }
            }
        });

        XposedBridge.hookAllConstructors(TextureView.class, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                try {
                    TextureView v = (TextureView) param.thisObject;
                    XposedBridge.log(TAG + ": TextureView constructed " + brief(v));
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": TextureView constructor log failed: " + t);
                }
            }
        });
    }

    private static View safeDecor(Activity activity) {
        try {
            Window w = activity != null ? activity.getWindow() : null;
            return w != null ? w.getDecorView() : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static void logActivity(String event, Activity a, boolean dumpTree) {
        if (a == null) return;
        try {
            Window w = a.getWindow();
            int flags = 0;
            int sysUi = 0;
            View decor = null;
            if (w != null) {
                WindowManager.LayoutParams lp = w.getAttributes();
                flags = lp != null ? lp.flags : 0;
                decor = w.getDecorView();
                if (decor != null) sysUi = decor.getSystemUiVisibility();
            }

            XposedBridge.log(TAG + ": " + event
                    + " activity=" + a.getClass().getName()
                    + " flags=0x" + Integer.toHexString(flags)
                    + " sysUi=0x" + Integer.toHexString(sysUi)
                    + " decor=" + (decor == null ? "null" : decor.getClass().getName()));

            if (dumpTree && decor != null) {
                int[] count = new int[]{0};
                dumpTree(decor, 0, count);
                XposedBridge.log(TAG + ": dumpEnd lines=" + count[0]);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": logActivity failed: " + t);
        }
    }

    private static void dumpTree(View v, int depth, int[] count) {
        if (v == null || depth > MAX_DEPTH || count[0] >= MAX_LOG_LINES_PER_DUMP) return;

        boolean interesting = isInterestingView(v);
        boolean large = v.getWidth() >= 600 && v.getHeight() >= 300;
        boolean shallow = depth <= 3;

        if (interesting || large || shallow) {
            XposedBridge.log(TAG + ": " + indent(depth) + brief(v));
            count[0]++;
        }

        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            int n = g.getChildCount();
            if ((interesting || large || shallow) && n > 0 && count[0] < MAX_LOG_LINES_PER_DUMP) {
                XposedBridge.log(TAG + ": " + indent(depth) + "children=" + n);
                count[0]++;
            }
            for (int i = 0; i < n; i++) {
                dumpTree(g.getChildAt(i), depth + 1, count);
                if (count[0] >= MAX_LOG_LINES_PER_DUMP) break;
            }
        }
    }

    private static boolean isInterestingView(View v) {
        if (v instanceof SurfaceView || v instanceof TextureView) return true;
        return isInterestingClass(v.getClass().getName()) || isInterestingString(safeResName(v));
    }

    private static boolean isInterestingClass(String name) {
        if (name == null) return false;
        String s = name.toLowerCase(Locale.ROOT);
        return s.contains("bili")
                || s.contains("theseus")
                || s.contains("player")
                || s.contains("video")
                || s.contains("surface")
                || s.contains("texture")
                || s.contains("render")
                || s.contains("ijk")
                || s.contains("danmaku")
                || s.contains("media")
                || s.contains("compose")
                || s.contains("texture")
                || s.contains("gl")
                || s.contains("webview");
    }

    private static boolean isInterestingString(String name) {
        if (name == null) return false;
        String s = name.toLowerCase(Locale.ROOT);
        return s.contains("player")
                || s.contains("video")
                || s.contains("surface")
                || s.contains("texture")
                || s.contains("render")
                || s.contains("bili")
                || s.contains("danmaku")
                || s.contains("media")
                || s.contains("fullscreen")
                || s.contains("screen")
                || s.contains("hdr");
    }

    private static String brief(View v) {
        if (v == null) return "null";
        String bg = "null";
        try {
            bg = v.getBackground() == null ? "null" : v.getBackground().getClass().getSimpleName();
        } catch (Throwable ignored) {}

        return v.getClass().getName()
                + " id=" + safeResName(v)
                + " shown=" + v.isShown()
                + " vis=" + visibility(v)
                + " alpha=" + v.getAlpha()
                + " bg=" + bg
                + " size=" + v.getWidth() + "x" + v.getHeight()
                + " pos=" + v.getLeft() + "," + v.getTop() + "," + v.getRight() + "," + v.getBottom()
                + " trans=" + v.getTranslationX() + "," + v.getTranslationY()
                + " z=" + safeZ(v);
    }

    private static String safeZ(View v) {
        try {
            return String.valueOf(v.getZ());
        } catch (Throwable t) {
            return "?";
        }
    }

    private static String visibility(View v) {
        int x = v.getVisibility();
        if (x == View.VISIBLE) return "VISIBLE";
        if (x == View.INVISIBLE) return "INVISIBLE";
        if (x == View.GONE) return "GONE";
        return String.valueOf(x);
    }

    private static String safeResName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID) return "NO_ID";
            return v.getResources().getResourceName(id);
        } catch (Throwable t) {
            try {
                return "id=" + v.getId();
            } catch (Throwable ignored) {
                return "id=?";
            }
        }
    }

    private static String indent(int depth) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < depth; i++) sb.append("  ");
        return sb.toString();
    }
}
