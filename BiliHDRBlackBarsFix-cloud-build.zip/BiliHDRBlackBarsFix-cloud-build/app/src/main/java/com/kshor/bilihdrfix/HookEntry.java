package com.kshor.bilihdrfix;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V7 Parent Background.
 *
 * Based on V6 result:
 * - Adding sibling overlay bars makes normal videos OK but HDR videos black.
 * - Therefore we stop adding ANY views.
 *
 * This version only sets the parent of tv.danmaku.render.core.SurfaceVideoRenderLayer to black.
 *
 * It does NOT touch:
 * - Window flags/background
 * - DecorView background
 * - SurfaceView / TextureView / SurfaceVideoRenderLayer properties
 * - network/auth/member/region/DRM/ad logic
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliHDRParentV7";
    private static final String VIDEO_RENDER_CLASS = "tv.danmaku.render.core.SurfaceVideoRenderLayer";

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bilibilihd",
            "tv.danmaku.bili",
            "com.bilibili.app.in"
    ));

    private static final WeakHashMap<ViewGroup, Boolean> PATCHED = new WeakHashMap<>();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded process=" + lpparam.processName + " package=" + lpparam.packageName);
        hookAddView();
        hookActivityScan();
    }

    private static void hookAddView() {
        XposedBridge.hookAllMethods(ViewGroup.class, "addView", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    View child = null;
                    for (Object arg : param.args) {
                        if (arg instanceof View) {
                            child = (View) arg;
                            break;
                        }
                    }
                    if (child != null && isVideoRender(child)) {
                        patchParent(parent, child, "addView");
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": addView hook failed: " + t);
                }
            }
        });
    }

    private static void hookActivityScan() {
        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow() == null ? null : a.getWindow().getDecorView();
                    if (decor != null) {
                        decor.postDelayed(() -> scan(decor, "resume+500"), 500);
                        decor.postDelayed(() -> scan(decor, "resume+1500"), 1500);
                        decor.postDelayed(() -> scan(decor, "resume+4000"), 4000);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": activity scan hook failed: " + t);
                }
            }
        });
    }

    private static void scan(View root, String reason) {
        try {
            if (root == null) return;
            if (isVideoRender(root)) {
                ViewGroup p = root.getParent() instanceof ViewGroup ? (ViewGroup) root.getParent() : null;
                if (p != null) patchParent(p, root, reason);
                return;
            }
            if (root instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) root;
                for (int i = 0; i < g.getChildCount(); i++) {
                    scan(g.getChildAt(i), reason);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": scan failed: " + t);
        }
    }

    private static boolean isVideoRender(View v) {
        return v != null && VIDEO_RENDER_CLASS.equals(v.getClass().getName());
    }

    private static void patchParent(final ViewGroup parent, final View surface, String reason) {
        if (parent == null || surface == null) return;

        try {
            parent.setBackgroundColor(Color.BLACK);
            parent.setWillNotDraw(false);

            if (!PATCHED.containsKey(parent)) {
                PATCHED.put(parent, Boolean.TRUE);
                XposedBridge.log(TAG + ": patched parent reason=" + reason
                        + " parent=" + brief(parent)
                        + " surface=" + brief(surface));
            }

            parent.postDelayed(() -> logState(parent, surface, "delay+1000"), 1000);
            parent.postDelayed(() -> logState(parent, surface, "delay+3000"), 3000);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchParent failed: " + t);
        }
    }

    private static void logState(ViewGroup parent, View surface, String reason) {
        try {
            XposedBridge.log(TAG + ": state " + reason
                    + " parent=" + brief(parent)
                    + " surface=" + brief(surface)
                    + " parentBg=" + (parent.getBackground() == null ? "null" : parent.getBackground().getClass().getName()));
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": logState failed: " + t);
        }
    }

    private static String brief(View v) {
        if (v == null) return "null";
        return v.getClass().getName()
                + " size=" + v.getWidth() + "x" + v.getHeight()
                + " pos=" + v.getLeft() + "," + v.getTop() + "," + v.getRight() + "," + v.getBottom()
                + " shown=" + v.isShown()
                + " alpha=" + v.getAlpha();
    }
}
