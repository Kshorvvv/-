package com.kshor.bilihdrfix;

import android.app.Activity;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V4 Log-only diagnostic build.
 *
 * This module intentionally changes NOTHING.
 * It only logs:
 * - Activity class names
 * - Window flags
 * - DecorView class/systemUiVisibility
 * - A shallow view tree, highlighting SurfaceView/TextureView
 *
 * Use it to find the exact player Activity/container before writing a precise fix.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliHDRDiag";

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bilibilihd",
            "tv.danmaku.bili",
            "com.bilibili.app.in"
    ));

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded in " + lpparam.packageName);
        hookActivityLifecycle();
    }

    private static void hookActivityLifecycle() {
        XposedBridge.hookAllMethods(Activity.class, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                logActivity("onCreate", a);
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                final Activity a = (Activity) param.thisObject;
                logActivity("onResume", a);
                View decor = safeDecor(a);
                if (decor != null) {
                    decor.postDelayed(() -> logActivity("onResume+1000ms", a), 1000);
                    decor.postDelayed(() -> logActivity("onResume+3000ms", a), 3000);
                }
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onWindowFocusChanged", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                logActivity("focusChanged=" + param.args[0], a);
            }
        });
    }

    private static View safeDecor(Activity activity) {
        try {
            Window w = activity != null ? activity.getWindow() : null;
            return w != null ? w.getDecorView() : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static void logActivity(String event, Activity a) {
        if (a == null) return;
        try {
            String cls = a.getClass().getName();
            Window w = a.getWindow();
            int flags = 0;
            int sysUi = 0;
            View decor = null;

            if (w != null) {
                WindowManager.LayoutParams lp = w.getAttributes();
                flags = lp != null ? lp.flags : 0;
                decor = w.getDecorView();
                if (decor != null) sysUi = decor.getSystemUiVisibility();
            }

            XposedBridge.log(TAG + ": " + event
                    + " activity=" + cls
                    + " flags=0x" + Integer.toHexString(flags)
                    + " sysUi=0x" + Integer.toHexString(sysUi)
                    + " decor=" + (decor == null ? "null" : decor.getClass().getName()));

            if (decor != null) {
                logTree(decor, 0, 4, 0);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": logActivity failed: " + t);
        }
    }

    private static int logTree(View v, int depth, int maxDepth, int count) {
        if (v == null || depth > maxDepth || count > 120) return count;

        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) indent.append("  ");

        boolean important = v instanceof SurfaceView || v instanceof TextureView;
        String name = v.getClass().getName();

        if (important || depth <= 2) {
            XposedBridge.log(TAG + ": " + indent
                    + name
                    + " id=" + safeResName(v)
                    + " shown=" + v.isShown()
                    + " alpha=" + v.getAlpha()
                    + " bg=" + (v.getBackground() == null ? "null" : v.getBackground().getClass().getSimpleName())
                    + " size=" + v.getWidth() + "x" + v.getHeight()
                    + " pos=" + v.getLeft() + "," + v.getTop() + "," + v.getRight() + "," + v.getBottom());
        }

        count++;

        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            int n = Math.min(g.getChildCount(), 40);
            for (int i = 0; i < n; i++) {
                count = logTree(g.getChildAt(i), depth + 1, maxDepth, count);
                if (count > 120) break;
            }
        }

        return count;
    }

    private static String safeResName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID) return "NO_ID";
            return v.getResources().getResourceName(id);
        } catch (Throwable t) {
            return "id=" + v.getId();
        }
    }
}
