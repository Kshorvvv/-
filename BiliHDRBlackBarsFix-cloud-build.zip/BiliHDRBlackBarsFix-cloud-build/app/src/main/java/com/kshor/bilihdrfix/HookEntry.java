package com.kshor.bilihdrfix;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V6 Overlay Bars.
 *
 * Based on V5 logs:
 * - video render surface: tv.danmaku.render.core.SurfaceVideoRenderLayer
 * - fullscreen HDR size on 2560x1600: SurfaceVideoRenderLayer = 2560x1440 at y=80
 *
 * This version does NOT touch:
 * - Window flags/background
 * - DecorView background
 * - SurfaceView / TextureView properties
 * - network/auth/member/region/DRM/ad logic
 *
 * It only adds normal black View overlays inside the SurfaceVideoRenderLayer's parent,
 * covering the empty area around the video surface.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliHDRBarsV6";
    private static final String VIDEO_RENDER_CLASS = "tv.danmaku.render.core.SurfaceVideoRenderLayer";

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bilibilihd",
            "tv.danmaku.bili",
            "com.bilibili.app.in"
    ));

    private static final WeakHashMap<ViewGroup, Bars> BARS = new WeakHashMap<>();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": loaded process=" + lpparam.processName + " package=" + lpparam.packageName);

        hookAddView();
        hookActivitySnapshots();
    }

    private static void hookAddView() {
        XposedBridge.hookAllMethods(ViewGroup.class, "addView", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    View child = null;
                    for (Object arg : param.args) {
                        if (arg instanceof View) {
                            child = (View) arg;
                            break;
                        }
                    }
                    if (child != null && isVideoRender(child)) {
                        XposedBridge.log(TAG + ": found video render via addView parent="
                                + brief(parent) + " child=" + brief(child));
                        attachBars(parent, child);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": addView hook failed: " + t);
                }
            }
        });
    }

    private static void hookActivitySnapshots() {
        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    final Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow() == null ? null : a.getWindow().getDecorView();
                    if (decor != null) {
                        decor.postDelayed(() -> scanAndAttach(decor), 500);
                        decor.postDelayed(() -> scanAndAttach(decor), 1500);
                        decor.postDelayed(() -> scanAndAttach(decor), 4000);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": activity snapshot hook failed: " + t);
                }
            }
        });
    }

    private static void scanAndAttach(View root) {
        try {
            if (root == null) return;
            if (isVideoRender(root)) {
                ViewGroup p = root.getParent() instanceof ViewGroup ? (ViewGroup) root.getParent() : null;
                if (p != null) attachBars(p, root);
                return;
            }
            if (root instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) root;
                for (int i = 0; i < g.getChildCount(); i++) {
                    scanAndAttach(g.getChildAt(i));
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": scanAndAttach failed: " + t);
        }
    }

    private static boolean isVideoRender(View v) {
        return v != null && VIDEO_RENDER_CLASS.equals(v.getClass().getName());
    }

    private static void attachBars(final ViewGroup parent, final View surface) {
        if (parent == null || surface == null) return;

        Bars bars = BARS.get(parent);
        if (bars == null) {
            bars = new Bars(parent);
            BARS.put(parent, bars);

            try {
                parent.addView(bars.top, new ViewGroup.LayoutParams(1, 1));
                parent.addView(bars.bottom, new ViewGroup.LayoutParams(1, 1));
                parent.addView(bars.left, new ViewGroup.LayoutParams(1, 1));
                parent.addView(bars.right, new ViewGroup.LayoutParams(1, 1));
                XposedBridge.log(TAG + ": bars attached to parent=" + brief(parent));
            } catch (Throwable t) {
                XposedBridge.log(TAG + ": adding bars failed: " + t);
                return;
            }

            try {
                final Bars finalBars = bars;
                parent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        updateBars(finalBars, surface);
                    }
                });
            } catch (Throwable t) {
                XposedBridge.log(TAG + ": layout listener failed: " + t);
            }
        }

        bars.surface = surface;

        // Run a few delayed updates because Bilibili resizes the render surface after entering fullscreen.
        final Bars finalBars1 = bars;
        parent.post(() -> updateBars(finalBars1, surface));
        parent.postDelayed(() -> updateBars(finalBars1, surface), 200);
        parent.postDelayed(() -> updateBars(finalBars1, surface), 800);
        parent.postDelayed(() -> updateBars(finalBars1, surface), 2000);
        parent.postDelayed(() -> updateBars(finalBars1, surface), 5000);
    }

    private static void updateBars(Bars bars, View surface) {
        if (bars == null || bars.parent == null || surface == null) return;

        try {
            ViewGroup parent = bars.parent;
            int pw = parent.getWidth();
            int ph = parent.getHeight();
            int l = surface.getLeft();
            int t = surface.getTop();
            int r = surface.getRight();
            int b = surface.getBottom();

            if (pw <= 0 || ph <= 0 || r <= l || b <= t) return;

            int topH = clamp(t, 0, ph);
            int bottomH = clamp(ph - b, 0, ph);
            int leftW = clamp(l, 0, pw);
            int rightW = clamp(pw - r, 0, pw);
            int midH = clamp(b - t, 0, ph);

            layoutBar(bars.top, 0, 0, pw, topH);
            layoutBar(bars.bottom, 0, b, pw, bottomH);
            layoutBar(bars.left, 0, t, leftW, midH);
            layoutBar(bars.right, r, t, rightW, midH);

            bars.top.bringToFront();
            bars.bottom.bringToFront();
            bars.left.bringToFront();
            bars.right.bringToFront();

            XposedBridge.log(TAG + ": update parent=" + pw + "x" + ph
                    + " surface=" + l + "," + t + "," + r + "," + b
                    + " bars top=" + topH + " bottom=" + bottomH
                    + " left=" + leftW + " right=" + rightW);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": updateBars failed: " + t);
        }
    }

    private static void layoutBar(View v, int x, int y, int w, int h) {
        if (v == null) return;

        if (w <= 0 || h <= 0) {
            v.setVisibility(View.GONE);
            return;
        }

        v.setVisibility(View.VISIBLE);
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (lp == null) lp = new ViewGroup.LayoutParams(w, h);
        if (lp.width != w || lp.height != h) {
            lp.width = w;
            lp.height = h;
            v.setLayoutParams(lp);
        }
        v.setX(x);
        v.setY(y);
    }

    private static int clamp(int x, int min, int max) {
        return Math.max(min, Math.min(max, x));
    }

    private static View makeBar() {
        View v = new View(AppHolder.anyContext);
        v.setBackgroundColor(Color.BLACK);
        v.setAlpha(1.0f);
        v.setClickable(false);
        v.setFocusable(false);
        v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return v;
    }

    private static String brief(View v) {
        if (v == null) return "null";
        return v.getClass().getName()
                + " size=" + v.getWidth() + "x" + v.getHeight()
                + " pos=" + v.getLeft() + "," + v.getTop() + "," + v.getRight() + "," + v.getBottom()
                + " shown=" + v.isShown();
    }

    private static final class Bars {
        final ViewGroup parent;
        final View top;
        final View bottom;
        final View left;
        final View right;
        View surface;

        Bars(ViewGroup parent) {
            this.parent = parent;
            AppHolder.anyContext = parent.getContext();
            this.top = makeBar();
            this.bottom = makeBar();
            this.left = makeBar();
            this.right = makeBar();
        }
    }

    private static final class AppHolder {
        static android.content.Context anyContext;
    }
}
