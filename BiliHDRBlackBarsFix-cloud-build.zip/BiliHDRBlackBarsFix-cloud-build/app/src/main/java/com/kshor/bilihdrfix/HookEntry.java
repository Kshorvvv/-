package com.kshor.bilihdrfix;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Safety scope:
 * - Only changes window/background/surface opacity for selected Bilibili packages.
 * - Does not touch network APIs, membership checks, region checks, playback authorization, DRM, cookies, tokens, or ads.
 *
 * Intended bug:
 * - On some Android 15 + Bilibili HD + HDR playback combinations, transparent/incorrectly-composited
 *   top/bottom letterbox areas may reveal wallpaper. This module tries to force those layers black/opaque.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliHDRBlackBarsFix";

    // Add/remove packages if your installed Bilibili HD package name is different.
    // Find it with: adb shell pm list packages | grep -i bili
    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bilibilihd",   // common Bilibili HD package name
            "tv.danmaku.bili",         // regular Bilibili, kept for testing if needed
            "com.bilibili.app.in"      // international build, kept harmless if not selected
    ));

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": loaded in " + lpparam.packageName);

        hookActivityLifecycle();
        hookSurfaceView();
        hookTextureView();
    }

    private static void hookActivityLifecycle() {
        XposedBridge.hookAllMethods(Activity.class, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity activity = (Activity) param.thisObject;
                applyBlackOpaqueWindow(activity);
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity activity = (Activity) param.thisObject;
                applyBlackOpaqueWindow(activity);
                View decor = activity.getWindow() != null ? activity.getWindow().getDecorView() : null;
                if (decor != null) {
                    decor.postDelayed(() -> applyBlackOpaqueWindow(activity), 300);
                    decor.postDelayed(() -> applyBlackOpaqueWindow(activity), 1000);
                }
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onWindowFocusChanged", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                Activity activity = (Activity) param.thisObject;
                applyBlackOpaqueWindow(activity);
            }
        });
    }

    private static void hookSurfaceView() {
        XposedBridge.hookAllConstructors(SurfaceView.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    SurfaceView sv = (SurfaceView) param.thisObject;
                    sv.setBackgroundColor(Color.BLACK);
                    sv.setAlpha(1.0f);
                    sv.setZOrderOnTop(false);
                    sv.setZOrderMediaOverlay(false);
                    SurfaceHolder holder = sv.getHolder();
                    if (holder != null) holder.setFormat(PixelFormat.OPAQUE);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": SurfaceView patch failed: " + t);
                }
            }
        });
    }

    private static void hookTextureView() {
        XposedBridge.hookAllConstructors(TextureView.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    TextureView tv = (TextureView) param.thisObject;
                    tv.setOpaque(true);
                    tv.setBackgroundColor(Color.BLACK);
                    tv.setAlpha(1.0f);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": TextureView patch failed: " + t);
                }
            }
        });
    }

    private static void applyBlackOpaqueWindow(Activity activity) {
        if (activity == null) return;

        try {
            Window w = activity.getWindow();
            if (w == null) return;

            // Make the window itself opaque.
            w.setBackgroundDrawable(new ColorDrawable(Color.BLACK));
            w.setFormat(PixelFormat.OPAQUE);

            WindowManager.LayoutParams lp = w.getAttributes();
            if (lp != null) {
                lp.alpha = 1.0f;
                lp.dimAmount = 0.0f;
                lp.format = PixelFormat.OPAQUE;
                if (Build.VERSION.SDK_INT >= 28) {
                    // Avoid accidental drawing into cutout areas as transparent wallpaper-revealing regions.
                    lp.layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER;
                }
                w.setAttributes(lp);
            }

            // Remove old translucent/system-overlap flags that may leave wallpaper visible behind letterbox bars.
            w.clearFlags(
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                            | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            );
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

            if (Build.VERSION.SDK_INT >= 21) {
                w.setStatusBarColor(Color.BLACK);
                w.setNavigationBarColor(Color.BLACK);
            }

            View decor = w.getDecorView();
            if (decor != null) {
                decor.setBackgroundColor(Color.BLACK);
                decor.setAlpha(1.0f);

                // Only touch the root-ish transparent layer, not every child view,
                // to avoid blacking out Bilibili's UI.
                if (decor instanceof ViewGroup) {
                    ViewGroup vg = (ViewGroup) decor;
                    if (vg.getChildCount() > 0) {
                        View first = vg.getChildAt(0);
                        if (first != null) first.setBackgroundColor(Color.BLACK);
                    }
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": window patch failed: " + t);
        }
    }
}
