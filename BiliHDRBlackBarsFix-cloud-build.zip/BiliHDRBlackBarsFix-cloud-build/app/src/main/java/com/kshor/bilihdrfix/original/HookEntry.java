package com.kshor.bilihdrfix.original;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V10 Original-only Content Root + Late Render Parent Background.
 *
 * Reason:
 * - V9 restores original behavior to "only flashes for a moment".
 * - Logs show gi1.c is already black after SurfaceVideoRenderLayer appears.
 * - So the flash probably happens BEFORE gi1.c / SurfaceVideoRenderLayer becomes available.
 *
 * V10 adds an earlier, safer layer:
 * - Patch android.R.id.content root background to black in normal Bilibili only.
 * - Also keep V9's render-parent black background when SurfaceVideoRenderLayer appears.
 *
 * It still does NOT touch:
 * - Window background / Window flags
 * - DecorView background
 * - SurfaceView / TextureView / SurfaceVideoRenderLayer properties
 * - overlay sibling bars
 * - network/auth/member/region/DRM/ad logic
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliOrigRootV10";
    private static final String VIDEO_RENDER_CLASS = "tv.danmaku.render.core.SurfaceVideoRenderLayer";

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bili"
    ));

    private static final WeakHashMap<View, Boolean> PATCHED_ROOTS = new WeakHashMap<>();
    private static final WeakHashMap<ViewGroup, Boolean> WATCHING_RENDER_PARENTS = new WeakHashMap<>();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded process=" + lpparam.processName + " package=" + lpparam.packageName);

        hookActivity();
        hookSetContentView();
        hookAddView();
    }

    private static void hookActivity() {
        XposedBridge.hookAllMethods(Activity.class, "onCreate", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                patchContentRoot(a, "onCreate");
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                patchContentRoot(a, "onResume");

                View content = getContentRoot(a);
                if (content != null) {
                    content.postDelayed(() -> patchContentRoot(a, "resume+100"), 100);
                    content.postDelayed(() -> patchContentRoot(a, "resume+500"), 500);
                    content.postDelayed(() -> scanForRender(content, "resume+500"), 500);
                    content.postDelayed(() -> scanForRender(content, "resume+1500"), 1500);
                    content.postDelayed(() -> scanForRender(content, "resume+3000"), 3000);
                }
            }
        });

        XposedBridge.hookAllMethods(Activity.class, "onWindowFocusChanged", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                Activity a = (Activity) param.thisObject;
                patchContentRoot(a, "focusChanged=" + param.args[0]);
            }
        });
    }

    private static void hookSetContentView() {
        XposedBridge.hookAllMethods(Activity.class, "setContentView", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam param) {
                patchContentRoot((Activity) param.thisObject, "beforeSetContentView");
            }

            @Override protected void afterHookedMethod(MethodHookParam param) {
                patchContentRoot((Activity) param.thisObject, "afterSetContentView");
            }
        });
    }

    private static void hookAddView() {
        XposedBridge.hookAllMethods(ViewGroup.class, "addView", new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    if (isAndroidContentRoot(parent)) {
                        patchRootView(parent, "beforeAddView-content-root");
                    }

                    View child = firstViewArg(param.args);
                    if (child != null && isVideoRender(child)) {
                        patchRenderParent(parent, child, "beforeAddView-video-render");
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": before addView hook failed: " + t);
                }
            }

            @Override protected void afterHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    if (isAndroidContentRoot(parent)) {
                        patchRootView(parent, "afterAddView-content-root");
                    }

                    View child = firstViewArg(param.args);
                    if (child != null && isVideoRender(child)) {
                        patchRenderParent(parent, child, "afterAddView-video-render");
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": after addView hook failed: " + t);
                }
            }
        });
    }

    private static View getContentRoot(Activity a) {
        try {
            return a == null ? null : a.findViewById(android.R.id.content);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void patchContentRoot(Activity a, String reason) {
        try {
            View content = getContentRoot(a);
            if (content != null) {
                patchRootView(content, reason);
                if (content instanceof ViewGroup) {
                    scanForRender(content, reason);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchContentRoot failed: " + t);
        }
    }

    private static void patchRootView(final View root, String reason) {
        if (root == null) return;
        try {
            root.setBackgroundColor(Color.BLACK);
            if (root instanceof ViewGroup) {
                ((ViewGroup) root).setWillNotDraw(false);
            }

            if (!PATCHED_ROOTS.containsKey(root)) {
                PATCHED_ROOTS.put(root, Boolean.TRUE);
                XposedBridge.log(TAG + ": patched content/root reason=" + reason + " root=" + brief(root));

                try {
                    root.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override public void onGlobalLayout() {
                            try {
                                root.setBackgroundColor(Color.BLACK);
                            } catch (Throwable ignored) {}
                        }
                    });
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": root global layout listener failed: " + t);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchRootView failed: " + t);
        }
    }

    private static boolean isAndroidContentRoot(View v) {
        if (v == null) return false;
        try {
            return v.getId() == android.R.id.content;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void scanForRender(View root, String reason) {
        try {
            if (root == null) return;

            if (isVideoRender(root)) {
                ViewGroup p = root.getParent() instanceof ViewGroup ? (ViewGroup) root.getParent() : null;
                if (p != null) patchRenderParent(p, root, "scan-" + reason);
                return;
            }

            if (root instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) root;
                int n = g.getChildCount();
                for (int i = 0; i < n; i++) {
                    scanForRender(g.getChildAt(i), reason);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": scanForRender failed: " + t);
        }
    }

    private static void patchRenderParent(final ViewGroup parent, final View surface, String reason) {
        if (parent == null) return;

        try {
            parent.setBackgroundColor(Color.BLACK);
            parent.setWillNotDraw(false);

            if (!WATCHING_RENDER_PARENTS.containsKey(parent)) {
                WATCHING_RENDER_PARENTS.put(parent, Boolean.TRUE);
                XposedBridge.log(TAG + ": watching render parent reason=" + reason
                        + " parent=" + brief(parent)
                        + " surface=" + brief(surface));

                try {
                    parent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override public void onGlobalLayout() {
                            try {
                                parent.setBackgroundColor(Color.BLACK);
                            } catch (Throwable ignored) {}
                        }
                    });
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": render parent global layout listener failed: " + t);
                }
            }

            parent.post(() -> setBlack(parent));
            parent.postDelayed(() -> setBlack(parent), 16);
            parent.postDelayed(() -> setBlack(parent), 100);
            parent.postDelayed(() -> setBlack(parent), 300);
            parent.postDelayed(() -> setBlack(parent), 1000);
            parent.postDelayed(() -> setBlack(parent), 3000);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchRenderParent failed: " + t);
        }
    }

    private static void setBlack(View v) {
        try {
            if (v != null) v.setBackgroundColor(Color.BLACK);
        } catch (Throwable ignored) {}
    }

    private static View firstViewArg(Object[] args) {
        if (args == null) return null;
        for (Object arg : args) {
            if (arg instanceof View) return (View) arg;
        }
        return null;
    }

    private static boolean isVideoRender(View v) {
        return v != null && VIDEO_RENDER_CLASS.equals(v.getClass().getName());
    }

    private static String brief(View v) {
        if (v == null) return "null";
        return v.getClass().getName()
                + " id=" + safeResName(v)
                + " size=" + v.getWidth() + "x" + v.getHeight()
                + " pos=" + v.getLeft() + "," + v.getTop() + "," + v.getRight() + "," + v.getBottom()
                + " shown=" + v.isShown()
                + " alpha=" + v.getAlpha();
    }

    private static String safeResName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID) return "NO_ID";
            return v.getResources().getResourceName(id);
        } catch (Throwable t) {
            return "id=" + v.getId();
        }
    }
}
