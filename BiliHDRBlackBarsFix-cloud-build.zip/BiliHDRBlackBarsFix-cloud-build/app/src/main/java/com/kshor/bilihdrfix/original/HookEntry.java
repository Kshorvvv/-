package com.kshor.bilihdrfix.original;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V9 Original-only Late Render Parent Background.
 *
 * V8 failed because it patched gi1.c too early when the parent was 0x0 and not shown.
 * V9 only patches when SurfaceVideoRenderLayer is being/has been added.
 *
 * Targets only normal Bilibili:
 * - tv.danmaku.bili
 *
 * Does NOT target Bilibili HD.
 * Does NOT touch Window, DecorView, SurfaceView/TextureView properties, auth, region, DRM, ads.
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliOrigLateV9";
    private static final String VIDEO_RENDER_CLASS = "tv.danmaku.render.core.SurfaceVideoRenderLayer";

    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bili"
    ));

    private static final WeakHashMap<ViewGroup, Boolean> WATCHING = new WeakHashMap<>();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded process=" + lpparam.processName + " package=" + lpparam.packageName);

        hookAddView();
        hookActivityScan();
    }

    private static void hookAddView() {
        XposedBridge.hookAllMethods(ViewGroup.class, "addView", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    View child = firstViewArg(param.args);
                    if (child != null && isVideoRender(child)) {
                        // Patch immediately before the video surface is inserted, but only for this real render child.
                        patchAndWatch(parent, child, "beforeAddView-video-render");
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": before addView hook failed: " + t);
                }
            }

            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    View child = firstViewArg(param.args);
                    if (child != null && isVideoRender(child)) {
                        patchAndWatch(parent, child, "afterAddView-video-render");
                        XposedBridge.log(TAG + ": video render found parent="
                                + brief(parent) + " child=" + brief(child));
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": after addView hook failed: " + t);
                }
            }
        });
    }

    private static void hookActivityScan() {
        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow() == null ? null : a.getWindow().getDecorView();
                    if (decor != null) {
                        decor.postDelayed(() -> scanForRender(decor, "resume+0.5s"), 500);
                        decor.postDelayed(() -> scanForRender(decor, "resume+1.5s"), 1500);
                        decor.postDelayed(() -> scanForRender(decor, "resume+3.0s"), 3000);
                        decor.postDelayed(() -> scanForRender(decor, "resume+6.0s"), 6000);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": activity scan hook failed: " + t);
                }
            }
        });
    }

    private static void scanForRender(View root, String reason) {
        try {
            if (root == null) return;

            if (isVideoRender(root)) {
                ViewGroup p = root.getParent() instanceof ViewGroup ? (ViewGroup) root.getParent() : null;
                if (p != null) patchAndWatch(p, root, "scan-" + reason);
                return;
            }

            if (root instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) root;
                for (int i = 0; i < g.getChildCount(); i++) {
                    scanForRender(g.getChildAt(i), reason);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": scanForRender failed: " + t);
        }
    }

    private static View firstViewArg(Object[] args) {
        if (args == null) return null;
        for (Object arg : args) {
            if (arg instanceof View) return (View) arg;
        }
        return null;
    }

    private static boolean isVideoRender(View v) {
        return v != null && VIDEO_RENDER_CLASS.equals(v.getClass().getName());
    }

    private static void patchAndWatch(final ViewGroup parent, final View surface, String reason) {
        if (parent == null) return;

        try {
            patchParent(parent, reason);

            if (!WATCHING.containsKey(parent)) {
                WATCHING.put(parent, Boolean.TRUE);

                try {
                    parent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override
                        public void onGlobalLayout() {
                            patchParent(parent, "globalLayout");
                        }
                    });
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": add global layout listener failed: " + t);
                }

                XposedBridge.log(TAG + ": watching parent=" + brief(parent) + " surface=" + brief(surface));
            }

            // Keep alive in case Bilibili clears/replaces background during HDR transition.
            parent.post(() -> patchParent(parent, "post0"));
            parent.postDelayed(() -> patchParent(parent, "post16"), 16);
            parent.postDelayed(() -> patchParent(parent, "post100"), 100);
            parent.postDelayed(() -> patchParent(parent, "post300"), 300);
            parent.postDelayed(() -> patchParent(parent, "post1000"), 1000);
            parent.postDelayed(() -> patchParent(parent, "post3000"), 3000);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchAndWatch failed: " + t);
        }
    }

    private static void patchParent(final ViewGroup parent, String reason) {
        if (parent == null) return;
        try {
            parent.setBackgroundColor(Color.BLACK);
            parent.setWillNotDraw(false);
            XposedBridge.log(TAG + ": patch reason=" + reason + " parent=" + brief(parent)
                    + " bg=" + (parent.getBackground() == null ? "null" : parent.getBackground().getClass().getName()));
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchParent failed: " + t);
        }
    }

    private static String brief(View v) {
        if (v == null) return "null";
        return v.getClass().getName()
                + " size=" + v.getWidth() + "x" + v.getHeight()
                + " pos=" + v.getLeft() + "," + v.getTop() + "," + v.getRight() + "," + v.getBottom()
                + " shown=" + v.isShown()
                + " alpha=" + v.getAlpha();
    }
}
