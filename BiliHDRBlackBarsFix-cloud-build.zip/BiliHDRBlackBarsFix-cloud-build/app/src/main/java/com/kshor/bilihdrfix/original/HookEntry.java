package com.kshor.bilihdrfix.original;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * V8 Original-only Early Parent Background.
 *
 * This module targets only normal Bilibili:
 * - package: tv.danmaku.bili
 *
 * It does NOT target Bilibili HD, so your separate stable HD V7 module can stay installed.
 *
 * It does NOT touch:
 * - Window flags/background
 * - DecorView background
 * - SurfaceView / TextureView / SurfaceVideoRenderLayer properties
 * - overlay sibling bars
 * - network/auth/member/region/DRM/ad logic
 */
public final class HookEntry implements IXposedHookLoadPackage {
    private static final String TAG = "BiliOrigEarlyV8";
    private static final String VIDEO_RENDER_CLASS = "tv.danmaku.render.core.SurfaceVideoRenderLayer";

    // Normal Bilibili 9.2.0 player parent from your logs.
    private static final Set<String> KNOWN_PLAYER_PARENT_CLASSES = new HashSet<>(Arrays.asList(
            "gi1.c"
    ));

    // Original Bilibili only. Do not include tv.danmaku.bilibilihd.
    private static final Set<String> TARGET_PACKAGES = new HashSet<>(Arrays.asList(
            "tv.danmaku.bili"
    ));

    private static final WeakHashMap<ViewGroup, Boolean> PATCHED = new WeakHashMap<>();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": loaded process=" + lpparam.processName + " package=" + lpparam.packageName);

        hookViewAttached();
        hookAddView();
        hookActivityScan();
    }

    private static void hookViewAttached() {
        XposedBridge.hookAllMethods(View.class, "onAttachedToWindow", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    View v = (View) param.thisObject;
                    if (v instanceof ViewGroup && isKnownPlayerParent((ViewGroup) v)) {
                        patchParent((ViewGroup) v, "onAttachedToWindow-known-parent");
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": onAttachedToWindow hook failed: " + t);
                }
            }
        });
    }

    private static void hookAddView() {
        XposedBridge.hookAllMethods(ViewGroup.class, "addView", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    if (isKnownPlayerParent(parent)) {
                        patchParent(parent, "beforeAddView-known-parent");
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": before addView hook failed: " + t);
                }
            }

            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    ViewGroup parent = (ViewGroup) param.thisObject;
                    View child = firstViewArg(param.args);

                    if (isKnownPlayerParent(parent)) {
                        patchParent(parent, "afterAddView-known-parent");
                    }

                    if (child != null && isVideoRender(child)) {
                        patchParent(parent, "afterAddView-video-render");
                        XposedBridge.log(TAG + ": video render found parent="
                                + brief(parent) + " child=" + brief(child));
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": after addView hook failed: " + t);
                }
            }
        });
    }

    private static void hookActivityScan() {
        XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    Activity a = (Activity) param.thisObject;
                    final View decor = a.getWindow() == null ? null : a.getWindow().getDecorView();
                    if (decor != null) {
                        decor.postDelayed(() -> scan(decor, "resume+0.3s"), 300);
                        decor.postDelayed(() -> scan(decor, "resume+1.0s"), 1000);
                        decor.postDelayed(() -> scan(decor, "resume+3.0s"), 3000);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": activity scan hook failed: " + t);
                }
            }
        });
    }

    private static void scan(View root, String reason) {
        try {
            if (root == null) return;

            if (root instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) root;
                if (isKnownPlayerParent(g)) {
                    patchParent(g, "scan-known-parent-" + reason);
                }

                if (isVideoRender(root)) {
                    ViewGroup p = root.getParent() instanceof ViewGroup ? (ViewGroup) root.getParent() : null;
                    if (p != null) patchParent(p, "scan-video-render-" + reason);
                    return;
                }

                for (int i = 0; i < g.getChildCount(); i++) {
                    scan(g.getChildAt(i), reason);
                }
            } else if (isVideoRender(root)) {
                ViewGroup p = root.getParent() instanceof ViewGroup ? (ViewGroup) root.getParent() : null;
                if (p != null) patchParent(p, "scan-video-render-" + reason);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": scan failed: " + t);
        }
    }

    private static View firstViewArg(Object[] args) {
        if (args == null) return null;
        for (Object arg : args) {
            if (arg instanceof View) return (View) arg;
        }
        return null;
    }

    private static boolean isVideoRender(View v) {
        return v != null && VIDEO_RENDER_CLASS.equals(v.getClass().getName());
    }

    private static boolean isKnownPlayerParent(ViewGroup v) {
        return v != null && KNOWN_PLAYER_PARENT_CLASSES.contains(v.getClass().getName());
    }

    private static void patchParent(final ViewGroup parent, String reason) {
        if (parent == null) return;

        try {
            parent.setBackgroundColor(Color.BLACK);
            parent.setWillNotDraw(false);

            if (!PATCHED.containsKey(parent)) {
                PATCHED.put(parent, Boolean.TRUE);
                XposedBridge.log(TAG + ": patched parent reason=" + reason + " parent=" + brief(parent));
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": patchParent failed: " + t);
        }
    }

    private static String brief(View v) {
        if (v == null) return "null";
        return v.getClass().getName()
                + " size=" + v.getWidth() + "x" + v.getHeight()
                + " pos=" + v.getLeft() + "," + v.getTop() + "," + v.getRight() + "," + v.getBottom()
                + " shown=" + v.isShown()
                + " alpha=" + v.getAlpha();
    }
}
