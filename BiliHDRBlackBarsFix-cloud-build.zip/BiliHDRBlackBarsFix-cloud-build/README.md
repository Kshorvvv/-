# Bili HDR Black Bars Fix V4 LogOnly

Drop-in replacement zip for your existing GitHub Actions workflow.

V4 is diagnostic-only:
- It changes nothing.
- It only logs Activity/window/view information to LSPosed logs.
- Video should remain normal, and the wallpaper leak may still remain.

After installing:
1. Enable module for Bilibili HD.
2. Force stop Bilibili HD.
3. Open one normal video and one HDR video, enter landscape/fullscreen.
4. Open LSPosed logs and search `BiliHDRDiag`.
5. Send the lines around `BiliHDRDiag` to tt.
