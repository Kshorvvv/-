# Bili HDR Fix V8 Original Only

Drop-in replacement zip for the existing GitHub Actions workflow.

Important:
- This APK uses a different applicationId: `com.kshor.bilihdrfix.original`
- It can be installed alongside your stable HD V7 module.
- It targets only original Bilibili: `tv.danmaku.bili`
- It does not target Bilibili HD.

Search logs:
- BiliOrigEarlyV8
