# Bili HDR Fix V9 Original Late

Drop-in replacement zip for the existing GitHub Actions workflow.

Important:
- applicationId: `com.kshor.bilihdrfix.original`
- This updates/replaces your Original-only V8 module.
- It does NOT touch your stable HD V7 module.
- Scope should be only `tv.danmaku.bili`.

Why V9:
- V8 patched `gi1.c` too early at size=0x0/shown=false.
- V9 patches only when `SurfaceVideoRenderLayer` is added or found.
- It repeatedly reapplies parent black background after render insertion.

Search logs:
- BiliOrigLateV9
