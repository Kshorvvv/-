# Bili HDR Fix V10 Original Root

Drop-in replacement zip for the existing GitHub Actions workflow.

Important:
- applicationId: `com.kshor.bilihdrfix.original`
- This updates/replaces your Original-only V8/V9 module.
- It does NOT touch your stable HD V7 module.
- Scope should be only `tv.danmaku.bili`.

Why V10:
- V9 confirms render parent `gi1.c` is black after SurfaceVideoRenderLayer appears.
- Remaining flash likely happens before `gi1.c` exists.
- V10 patches normal Bilibili's android.R.id.content root background to black earlier,
  while keeping V9's render-parent black background.

Search logs:
- BiliOrigRootV10
