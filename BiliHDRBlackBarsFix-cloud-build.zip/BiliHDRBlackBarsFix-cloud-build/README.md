# Bili HDR Black Bars Fix V2 Conservative

This is a corrected drop-in replacement zip.

Important:
- Top-level folder name is `BiliHDRBlackBarsFix-cloud-build`.
- Gradle files are included.
- It does not hook SurfaceView or TextureView, to avoid black video playback.
