# Bili HDR Black Bars Fix / B站 HD HDR 黑边补丁（LSPosed 源码）

## 作用

这个模块只做一件事：

- 在 Bilibili/Bilibili HD 进程内，把 Activity Window、DecorView、SurfaceView、TextureView 尽量强制成黑色不透明背景；
- 用来缓解 Android 15 + B站 HD 2.5.1 + HDR 播放时，上下黑边/安全区意外露出壁纸的问题。

它不会也不应该做这些事：

- 不改接口；
- 不改会员判断；
- 不改地区版权；
- 不改播放鉴权；
- 不碰 DRM / cookie / token / 广告逻辑。

## 你给的环境

- B站 HD：2.5.1
- Android：15
- LSPosed：2.0.1 (7639)

## 构建方式

1. 用 Android Studio 打开这个文件夹。
2. 等 Gradle 同步完成。
3. Build > Build APK(s)。
4. 安装生成的 APK。
5. 打开 LSPosed，在模块里启用它。
6. 勾选目标 App，优先选 Bilibili HD。
7. 强制停止 B站 HD，重新打开测试 HDR 播放。

## 如果没效果

先确认包名。连接 ADB 后执行：

```bash
adb shell pm list packages | grep -i bili
```

如果你的 B站 HD 包名不是：

- `tv.danmaku.bilibilihd`

那就打开：

```text
app/src/main/java/com/kshor/bilihdrfix/HookEntry.java
```

把你的包名加入 `TARGET_PACKAGES` 列表，然后重新编译安装。

## 如果黑边修好了但 UI 异常

把这行注释掉再编译：

```java
first.setBackgroundColor(Color.BLACK);
```

如果仍异常，再注释掉 `hookSurfaceView()` 或 `hookTextureView()` 中对应调用做二分排查。

## 备注

这不是“完美修复”，是一个保守的兼容性补丁。HDR 播放链路可能涉及系统合成器、Surface、播放器内核、厂商 ROM 和 B站自身渲染逻辑，所以有些机型需要进一步针对具体 Activity/播放器 View 精准 hook。


## 没电脑：用 GitHub Actions 云端编译 APK

这是最适合“只有手机/平板”的办法。

1. 注册/登录 GitHub。
2. 新建一个私有仓库。
3. 在仓库网页里上传本项目解压后的全部文件。
4. 打开仓库的 `Actions` 页面。
5. 选择 `Build LSPosed APK`。
6. 点 `Run workflow`。
7. 等构建完成后，进入这次 workflow run。
8. 在页面底部 `Artifacts` 下载 `BiliHDRBlackBarsFix-debug-apk`。
9. 解压 artifact，里面就是 `app-debug.apk`。
10. 安装 APK，然后去 LSPosed 启用模块并勾选 B站 HD。

如果浏览器提示 artifact 是 zip，这是正常的；GitHub Actions 会把 APK 包在 zip 里给你下载。
