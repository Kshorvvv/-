# Bili HDR Fix V6 Overlay Bars

Drop-in replacement zip for your existing GitHub Actions workflow.

V6 does not touch Window/Decor/Surface properties. It only overlays normal black Views
around `tv.danmaku.render.core.SurfaceVideoRenderLayer`.

Expected from V5 logs:
- parent: 2560x1600
- SurfaceVideoRenderLayer: 2560x1440 at y=80
- V6 should add top/bottom 80 px black bars.

Install steps:
1. Uninstall previous Bili HDR Fix module APK.
2. Build/install this APK.
3. Enable scope for Bilibili HD.
4. Force stop Bilibili HD.
5. Test HDR fullscreen.
6. If video is still normal but bars remain wallpaper, export logs and search `BiliHDRBarsV6`.
