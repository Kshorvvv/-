# Bili HDR Fix V5 DeepLog

Drop-in replacement zip for your existing GitHub Actions workflow.

V5 changes nothing. It logs deeper view tree information and Surface/Texture creation.

After installing:
1. Disable/uninstall old V1/V2/V3/V4 module if needed.
2. Install this APK.
3. Enable scope only for Bilibili HD.
4. Clear LSPosed logs.
5. Force stop Bilibili HD.
6. Open one HDR video, enter fullscreen/landscape for 10–15 seconds.
7. Export LSPosed logs and send them back.
8. Search keyword: BiliHDRDeep.
