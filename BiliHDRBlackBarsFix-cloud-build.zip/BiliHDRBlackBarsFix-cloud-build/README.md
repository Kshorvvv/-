# Bili HDR Black Bars Fix V3 Flags-only

This is a drop-in replacement zip with the same file name and top-level folder name expected by the existing GitHub Actions workflow.

V3 changes:
- Does not touch SurfaceView or TextureView.
- Does not set Activity/DecorView background black.
- Only clears wallpaper/translucent/no-limits window flags and sets system bars black.

If V3 still makes the video black, the old module/APK is probably still active or cached; uninstall old module and reboot.
If V3 restores video but wallpaper leaks again, the issue is the HDR video surface/compositor path, not a simple background-layer problem.
