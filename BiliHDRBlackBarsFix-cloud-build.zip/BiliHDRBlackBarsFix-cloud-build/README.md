# Bili HDR Fix V7 ParentBG

Drop-in replacement zip for your existing GitHub Actions workflow.

V7 changes:
- No overlay bars.
- No Window/Decor changes.
- No Surface/Texture property changes.
- Only sets the parent of `tv.danmaku.render.core.SurfaceVideoRenderLayer` to black.

If HDR is no longer black but wallpaper still leaks, parent background is not enough.
If HDR is black, even parent background affects HDR composition and this path should be abandoned.
Search logs: BiliHDRParentV7
